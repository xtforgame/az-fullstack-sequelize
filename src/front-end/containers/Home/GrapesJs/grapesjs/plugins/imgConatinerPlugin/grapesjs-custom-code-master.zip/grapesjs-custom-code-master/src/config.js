const keyCustomCode = 'custom-code-plugin__code';
const typeCustomCode = 'custom-code';
const commandNameCustomCode = 'custom-code:open-modal';

export {
  keyCustomCode,
  typeCustomCode,
  commandNameCustomCode,
}
